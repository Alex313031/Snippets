export class ProgressDialog {
  constructor() {
    this.onPrimaryClicked = null;
    this.onSecondaryClicked = null;

    const self = this;
    this.primaryBtn().addEventListener('click', function() {
      self.onPrimaryClicked();
    });
    this.secondaryBtn().addEventListener('click', function() {
      self.onSecondaryClicked();
    });
  }

  // Get the primary button
  primaryBtn() {
    return document.getElementById('primaryBtn');
  }

  // Get the secondary button
  secondaryBtn() {
    return document.getElementById('secondaryBtn');
  }

  // Set whether the primary button is enabled
  setPrimaryBtnEnabled(enabled) {
    this.setElementEnabled(this.primaryBtn(), enabled);
  }

  // Set whether the secondary button is enabled
  setSecondaryBtnEnabled(enabled) {
    this.setElementEnabled(this.secondaryBtn(), enabled);
  }

  // Set the primary button's label
  setPrimaryBtnText(text) {
    this.primaryBtn().innerHTML = text;
  }

  // Add or remove the 'disabled' class from |elem|
  setElementEnabled(elem, enabled) {
    if (enabled) {
      elem.classList.remove('disabled');
    } else {
      elem.classList.add('disabled');
    }
  }

  // Change the status message
  setStatusText(text) {
    const elem = document.getElementById('status');
    elem.innerHTML = text;
  }

  // Change progress bar value
  setPercentProgress(progress) {
    const elem = document.getElementById('progress');
    elem.style.width = `${progress}%`;
  }
}
