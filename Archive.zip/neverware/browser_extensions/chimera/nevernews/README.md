# Neverware News Extension

## Purpose

Inform/remind users of the free product that we have products they
might enjoy paying for. Also displays highlights for the release and a
link to the release notes.

The contents of this extension are referred to as "the news" below.

More details: https://neverware.atlassian.net/browse/OVER-4751

## Behavior

Display the news in a frameless window when a user first logs
in. Subsequent logins by the same user will not show the window again
unless we release a new version of the news. Since the extension is
bundled in the OS release this implies that the news will be shown to
a user no more than once per release.

Note that guest users are never shown the news. Users of the paid
products are also not shown the news.

Note that the version in the extension manifest must be updated for
user to see new news.

## Implementation

The HTML/CSS is pretty self-explanatory. Note that it's
self-contained, i.e. it doesn't rely on any internal Chrome
resources. This means you can load [news.html](news.html) in a normal
browser to check how it will look as you make changes.

It does reach out to get the latest news from s3, falling back on
defaults that are only present when built or if you run
`download_default_nevernews.py`.

Technically this extension is a Chrome App, but there isn't really a
big distinction between apps and extensions. A couple app features are
used to make a frameless window and to prevent it from showing in the
launcher.

A "background" script registers a handler for the launch event, and
the handler uses the storage API to check whether the news has been
shown, and if so what version was shown. Depending on the results, it
will then either show the news or do nothing.

There's some code in the browser that does the actual launching:

	StartupBrowserCreator::LaunchBrowser
      chrome/browser/ui/startup/startup_browser_creator.cc
	
	MaybeDisplayNeverwareNews
	  chrome/browser/chromeos/neverware/neverware_news.cc

Some of this is probably unnecessary complexity; we should be able to
launch the app unconditionally and let it determine whether to show
itself. But the current method works and I want to stop messing with
it.
