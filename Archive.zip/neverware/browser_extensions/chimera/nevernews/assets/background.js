/* global chrome */

/* Derive the current major version of the OS
 *
 * returns the major version, e.g. for version '33.2.1' returns '33'
 *
 * NB: We would return the minor version, too, but it's not accurate.
 * The user agent pulls from browser/src/chrome/VERSION, which isn't kept
 * up-to-date when we branch.
 */
function getMajorVersion() {
  // I literally can't find an API that offers this information directly
  const userAgent = navigator.userAgent;
  const re = userAgent.match(/Chrome\/(\d+)\./);
  return re[1];
}

function background() {
  'use strict';

  const kLastShownVersion = 'lastShownVersion';

  const currentVersion = getMajorVersion();

  function showNews() {
    // Store that we have shown this version of the news
    chrome.storage.local.set({[kLastShownVersion]: currentVersion}, function() {
      if (chrome.runtime.lastError === undefined) {
        console.log('nevernews: stored version');
      } else {
        console.log('nevernews: error! ' + chrome.runtime.lastError.message);
      }
    });

    // Display the news window
    chrome.app.window.create('nevernews/news.html', {
      frame: 'none',
      resizable: false,
      hidden: false,
      outerBounds: {
        width: 900,
        height: 530,
      }
    });
  }

  function launch(launchData) {
    console.log('launchData.source: ' + launchData.source);

    // Always show news when explicitly launched. This is unlikely to
    // occur in normal use (the user would have to pin the app to the
    // launcher when it gets shown) but seems like the right
    // behavior. It's useful for dev purposes too.
    if (launchData.source == 'app_launcher') {
      showNews();
      return;
    }

    chrome.storage.local.get(kLastShownVersion, function(data) {
      const lastShownVersion = data[kLastShownVersion];
      console.log('nevernews: lastShownVersion=' +
                  lastShownVersion +
                  ', currentVersion=' +
                  currentVersion);

      if (lastShownVersion === undefined) {
        // User has never seen the news
        showNews();
      } else if (currentVersion != lastShownVersion) {
        // This is a different version of the news. Presumably it is a
        // newer version of the news...
        showNews();
      }
    });
  }

  chrome.app.runtime.onLaunched.addListener(launch);
}

background();
