document.addEventListener('DOMContentLoaded', function() {
  const closeBtn = document.getElementById('close-btn');
  closeBtn.addEventListener('click', function() {
    window.close();
  });

  /* Attempts to grab the latest news (pulling the version from our
   * background page). If it fails at any point to get it, falls back
   * on loading it from a local file via an import link in news.html
   */
  const newsDiv = document.getElementById('whats-new');
  new Promise(function(resolve, reject) {
    chrome.runtime.getBackgroundPage(page => resolve(page));
    // Unclear to me if this can fail. Avoid hang if it never returns?
    setTimeout(reject, 1000, 'Never got background page.');
  }).then(page => {
    const currentVersion = page.getMajorVersion();
    const url = `https://news.neverware.com/${currentVersion}.json`;
    return window.fetch(url);
  }).then(response => {
    return response.json();
  }).then(json => {
    return json['html'];
  }).catch(err => {
    console.log(`couldn't get the freshest news (${err}), loading default.`);
    const defaultNews = document.getElementById('default-news');
    const body = defaultNews.import.body;
    return body.innerHTML;
  }).then(
    html => {
      newsDiv.innerHTML = html;
    },
    err => {
      newsDiv.innerHTML = 'Unable to retrieve CloudReady news';
    }
  );
});
