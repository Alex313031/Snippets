#! /usr/bin/env python3
"""Sets up files to allow for reliable, up-to-date nevernews"""

import argparse
import os
import requests


def parse_args(args=None):
    """Parse sys.args or a passed array of args, return argparse namespace"""
    parser = argparse.ArgumentParser()

    # required optional args for clarity in calling script
    parser.add_argument(
        '--output-dir',
        required=True,
        help='where to spit out our files')

    parser.add_argument(
        '--version',
        required=True,
        help="version we're building")

    return parser.parse_args(args)


def format_version(version):
    """Grab the first two parts of a multi-part version, or supply default"""
    if version == '':
        return '0.0'

    parts = version.split('.')
    return '{}.{}'.format(parts[0], parts[1])


def download_nevernews(version, output_dir):
    """Download nevernews and pack it and a link to it into files"""
    version = format_version(version)
    news_url = ("https://news.neverware.com/{}.json".format(version))

    # This must be kept in sync with news.html
    default_news_file = os.path.join(output_dir, 'default-news.html')

    try:
        response = requests.get(news_url)
        news_json = response.json()
        default_html = news_json['html']
    except (requests.RequestException, ValueError):
        # If this fails the file is probably missing.
        # Someone'll put it in place eventualy,
        # just shove a default value in there.
        default_html = "Unable to retrieve CloudReady news"

    with open(default_news_file, 'w') as wfp:
        wfp.write(default_html)


def main():
    """Trivial main"""
    args = parse_args()
    download_nevernews(args.version, args.output_dir)


if __name__ == '__main__':
    main()
